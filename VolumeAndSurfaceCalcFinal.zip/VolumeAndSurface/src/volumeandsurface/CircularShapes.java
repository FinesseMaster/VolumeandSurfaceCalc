/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package volumeandsurface;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Shadow
 */
public class CircularShapes extends VolumeAndSurface implements SuperInterface{

    private float radius;
    Scanner input = new Scanner(System.in);

    //Constructor for sphere shapes
    public CircularShapes(float radius) {
        while (true) {
            try {
                System.out.print("Please input a radius value: ");
                this.radius = input.nextFloat();

                if (radius < 0) {
                    System.out.print("Not an actual number!");
                  input.nextFloat();
                    continue;
                }
                break;
            } catch (InputMismatchException e) {
                input.next();
                System.out.println("Not an actual value!");
            }
        }
    }
    //Constructor for cylinder
    public CircularShapes(float radius, float length) {
        while (true) {
            try {
                System.out.println("Please input a radius value: ");
                this.radius = input.nextFloat();

                if (radius < 0) {
                    System.out.println("Please input a real value!");
                   input.nextFloat();
                    continue;
                }
                break;
            } catch (InputMismatchException e) {
                input.next();
                System.out.println("Not an actual value!");
            }
        }
        while (true) {
            try {
                System.out.print("Please input a length value: ");
               this.length = input.nextFloat();

                if (length < 0) {
                    System.out.print("Please input a real value!");
                    input.nextFloat();
                    continue;
                }
                break;
            } catch (InputMismatchException e) {
                input.next();
                System.out.println("Not an actual value!");
            }
        }
    }
    //Calculations for sphere
    public void surfaceCalc(float radius) {
        surArea=(float)(4*Math.PI*Math.pow(this.radius, 2));
        System.out.printf("The surface area is %.2f", surArea);
        System.out.println("");
    }
    
    public void volumeCalc(float radius){
        volume=(float)(4/3*Math.PI*Math.pow(this.radius, 3));
        System.out.printf("The volume is %.2f", volume);
    }
    //Calculations for cylinder, overloading the volumeCalc and surfaceCalc methods
    public void surfaceCalc(float radius, float height) {
        surArea=(float)(2*Math.PI*this.radius*this.height+ 2*Math.PI*Math.pow(this.radius, 2));
        System.out.printf("The surface area is %.2f", surArea);
        System.out.println("");
}
    public void volumeCalc(float radius, float height){
        volume=(float)(Math.PI*Math.pow(this.radius, 2));
        System.out.printf("The volume is %.2f", volume);
    }
    
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package volumeandsurface;

import java.util.Scanner;
import java.util.InputMismatchException;


public class RectPrism extends VolumeAndSurface implements SuperInterface{

     Scanner input = new Scanner(System.in);

    public RectPrism() {
        //Code to check for actual height, length, and width values   
        while(true){
        try {
            System.out.print("Please input a length value: ");
            length = input.nextFloat();
           
           if (length < 0) {
                System.out.print("Not a possible number! Please try again");
                 input.nextFloat();
                continue;
            }
           break;
        } catch (InputMismatchException e) {
            input.next();
            System.out.println("Not an actual value!");
            
        }
        }
       
        while(true){
        try {
            System.out.print("Please input a width value: ");
            width = input.nextFloat();
           
           if (width < 0) {
                System.out.print("Not a real number! Please input a valid number: ");
                width = input.nextFloat();
                continue;
            }
           break;
        } catch (InputMismatchException e) {
          input.next();
            System.out.println("Not an actual value!");    
        }
        }
        
        while(true){
        try {
            System.out.print("Please input a height value: ");
            height = input.nextFloat();
           
           if (height < 0) {
                System.out.print("Not a real number! Please input a valid number: ");
                height = input.nextFloat();
                continue;
            }
           break;
        } catch (InputMismatchException e) {
            input.next();
            System.out.println("Not an actual value!");    
        }
        }
 
    }

    //Methods is for rectangular prism
    
     @Override
    public void surfaceCalc() {
        surArea = ((width * height) + (length * height) + (length * width)) * 2;
        System.out.println("The surface area is " + surArea);

    }

     @Override
    public void volumeCalc() {
        volume = width *length * height;
        System.out.println("The volume is "+ volume);

    }

}

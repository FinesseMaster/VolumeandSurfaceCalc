package volumeandsurface;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Shadow
 */
public class SquPyramid extends VolumeAndSurface implements SuperInterface {

    private float slanthei;
    private float base;

    Scanner input = new Scanner(System.in);

    //Validating for proper slant height, height, and base.
    public SquPyramid() {
        while (true) {
            try {
                System.out.println("Please input a slant height of the triangle faces: ");
                slanthei = input.nextFloat();

                if (slanthei < 0) {
                    System.out.print("Not a real number! Please try again:");
                    slanthei = input.nextFloat();
                }
                break;
            } catch (InputMismatchException e) {
                input.next();
                System.out.println("Not an actual value!");
            }
        }
            while (true) {
                try {
                    System.out.println("Please input the base length");
                    base = input.nextFloat();

                    if (base < 0) {
                        System.out.print("Not a real number! Please try again:");
                        base = input.nextFloat();
                    }
                    break;
                } catch (InputMismatchException e) {
                    input.next();
                    System.out.println("Not an actual value!");
                }
            }

            while (true) {
                try {
                    System.out.println("Please input the height of the pyramid ");
                    height = input.nextFloat();

                    if (height < 0) {
                        System.out.print("Not a real number! Please try again:");
                        height = input.nextFloat();
                    }
                    break;
                } catch (InputMismatchException e) {
                    input.next();
                    System.out.println("Not an actual value!");
                }
            }
        }

    

    @Override
    public void surfaceCalc() {
        surArea = (float) (Math.pow(base, 2) + 2 * base * slanthei);
        System.out.println("The surface area of the pyramid is " + surArea);
    }

    @Override
    public void volumeCalc() {
        volume = (float) ((Math.pow(base, 2) * height) / 3);
        System.out.println("The surface area of the pyramid is " + volume);

    }
}

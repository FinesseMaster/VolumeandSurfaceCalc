package volumeandsurface;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Shadow
 */
public class VolumeAndSurface implements SuperInterface {

    //The basic dimensions for the shapes
    float surArea;
    float volume;
    float height;
    float length;
    float width;

    public void surfaceCalc() {
    }

    public void volumeCalc() {
    }

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("Hello user! This is a simple program that will calculate the surface area and the volume of a one of the 3d shapes. Here are the options:");
        System.out.println("Please pick the number corresponding to the shape: \n1.Cube \n2.Sphere \n3.Cylinder \n4.Square Pyramid \n5.Rectangular Prism");

        int userIn;
        while (true) {
            try {
                userIn = input.nextInt();
                while (userIn < 0 || userIn > 5) {
                    System.out.println("Not a valid option! Try again please!");
                    userIn = input.nextInt();

                }
                break;
            } catch (InputMismatchException e) {
                System.out.println("Not an actual value! Please try again");
                input.next();
            }
        }
        
        switch (userIn) {
            case 1:
                Cube myCube = new Cube();
                myCube.surfaceCalc();
                myCube.volumeCalc();
                break;
            case 2:
                CircularShapes mySphere = new CircularShapes(0);
                mySphere.surfaceCalc(0);
                mySphere.volumeCalc(0);
                break;
            case 3:
                CircularShapes myCyli = new CircularShapes(0, 0);
                myCyli.surfaceCalc(0, 0);
                myCyli.volumeCalc(0, 0);
                break;
            case 4:
                SquPyramid myPyra = new SquPyramid();
                myPyra.volumeCalc();
                myPyra.surfaceCalc();
                break;

            case 5:
                RectPrism myPrism = new RectPrism();
                myPrism.surfaceCalc();
                myPrism.volumeCalc();
                break;
        }

    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package volumeandsurface;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Shadow
 */
public class Cube extends VolumeAndSurface implements SuperInterface{
    Scanner input= new Scanner(System.in);
    //Constructor for cube.
    public Cube(){
        //Checking for valid side length of cube
        while(true){
        try {
            System.out.print("Please input a length value: ");
            this.length = input.nextFloat();
           
           if (length < 0) {
                System.out.print("Not an actual value! Please input a real number: ");
                this.length = input.nextFloat();
                continue;
            }
           break;
        } catch (InputMismatchException e) {
            input.next();
            System.out.println("Not an actual value!");  
            
        }
        }
    
}
    //Mathematical calculations for surface area and volume of cube
    @Override
    public void surfaceCalc(){
       surArea=(float)(6*(Math.pow(length, 2)));
        System.out.println("The surface area of the cube is "+ surArea);
    }
    
    @Override
    public void volumeCalc(){
        volume=(float)(Math.pow(length, 3));
        System.out.println("The volume of the cube is "+ volume);
        
    }
}
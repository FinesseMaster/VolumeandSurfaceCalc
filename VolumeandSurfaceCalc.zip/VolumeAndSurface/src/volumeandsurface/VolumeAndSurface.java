/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package volumeandsurface;

/**
 *
 * @author Shadow
 */
public class VolumeAndSurface implements CalcInterface {

    

     float surArea;
     float volume;
     float height;
     float length;
     float base;
     float width;
   
    //attempt to use encapsulation
    public void setHeight(float setHei) {
        height = setHei;
    }

    public float surfaceCalc(){
        return surArea;
    }
  
    public float volumeCalc() {
        return volume;
    }

    public static void main(String[] args) {

        RectPrism myPrism = new RectPrism();
        myPrism.surfaceCalc(0, 0, 0);
        myPrism.volumeCalc(0, 0, 0);

    }

}

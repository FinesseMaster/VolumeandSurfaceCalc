/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package volumeandsurface;

import java.util.Scanner;

/**
 *
 * @author Shadow
 */
public class Cylinder extends VolumeAndSurface{
     private float radius;
    Scanner input=new Scanner(System.in);
    
    public void surfaceCalc(float radius, float height){
        System.out.print("Please input a radius value: ");
        this.radius=radius;
        
        System.out.print("Please input a height value: ");
        this.height=height;
        
    }
}
